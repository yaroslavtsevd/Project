import type { ListResponse } from "../models/common.model.js";
import type {
  AnswerResponseDto,
  CreateAnswerRequestDto,
  PatchAnswerRequestDto,
  UpdateAnswerRequestDto,
} from "../dtos/answers.dto.js";
import { toAnswerResponseDto } from "../dtos/answers.dto.js";
import { ApiError } from "../errors/ApiError.js";
import { answersRepository } from "../repositories/answers.repository.js";
import { questionsRepository } from "../repositories/questions.repository.js";
import { usersRepository } from "../repositories/users.repository.js";
import { compareValues, paginate, parseListQuery } from "../utils/listQuery.js";

export class AnswersService {
  getList(query: Record<string, unknown>): ListResponse<AnswerResponseDto> {
    const listQuery = parseListQuery(query);
    const questionId = typeof query.questionId === "string" ? Number(query.questionId) : undefined;
    const userId = typeof query.userId === "string" ? Number(query.userId) : undefined;
    let items = answersRepository.getAll(listQuery.includeDeleted);

    if (questionId && Number.isInteger(questionId))
      items = items.filter((answer) => answer.questionId === questionId);
    if (userId && Number.isInteger(userId))
      items = items.filter((answer) => answer.userId === userId);

    const allowedSort = new Set(["id", "questionId", "userId", "createdAt"]);
    if (listQuery.sortBy && allowedSort.has(listQuery.sortBy)) {
      items = [...items].sort((a, b) =>
        compareValues(
          String(a[listQuery.sortBy as keyof typeof a]),
          String(b[listQuery.sortBy as keyof typeof b]),
          listQuery.sortDir,
        ),
      );
    }

    const total = items.length;
    const pageItems = paginate(items, listQuery.page, listQuery.pageSize).map(toAnswerResponseDto);
    return { items: pageItems, total, page: listQuery.page, pageSize: listQuery.pageSize };
  }

  getById(id: number): AnswerResponseDto {
    const answer = answersRepository.getById(id);
    if (!answer) throw ApiError.notFound("Answer not found");
    return toAnswerResponseDto(answer);
  }

  create(dto: CreateAnswerRequestDto): AnswerResponseDto {
    this.checkRelations(dto.questionId, dto.userId);
    const duplicate = answersRepository.findByQuestionAndUser(dto.questionId, dto.userId);
    if (duplicate) throw ApiError.conflict("This user has already answered this question");

    const now = new Date().toISOString();
    const answer = answersRepository.create({
      ...dto,
      createdAt: now,
      updatedAt: now,
      deletedAt: null,
    });
    return toAnswerResponseDto(answer);
  }

  update(id: number, dto: UpdateAnswerRequestDto): AnswerResponseDto {
    const current = answersRepository.getById(id);
    if (!current) throw ApiError.notFound("Answer not found");
    this.checkRelations(dto.questionId, dto.userId);

    const duplicate = answersRepository.findByQuestionAndUser(dto.questionId, dto.userId);
    if (duplicate && duplicate.id !== id)
      throw ApiError.conflict("This user has already answered this question");

    const updated = answersRepository.replace(id, {
      ...dto,
      updatedAt: new Date().toISOString(),
      deletedAt: null,
    });
    if (!updated) throw ApiError.notFound("Answer not found");
    return toAnswerResponseDto(updated);
  }

  patch(id: number, dto: PatchAnswerRequestDto): AnswerResponseDto {
    const current = answersRepository.getById(id);
    if (!current) throw ApiError.notFound("Answer not found");

    const nextQuestionId = dto.questionId ?? current.questionId;
    const nextUserId = dto.userId ?? current.userId;
    this.checkRelations(nextQuestionId, nextUserId);

    const duplicate = answersRepository.findByQuestionAndUser(nextQuestionId, nextUserId);
    if (duplicate && duplicate.id !== id)
      throw ApiError.conflict("This user has already answered this question");

    const updated = answersRepository.patch(id, { ...dto, updatedAt: new Date().toISOString() });
    if (!updated) throw ApiError.notFound("Answer not found");
    return toAnswerResponseDto(updated);
  }

  delete(id: number): void {
    const answer = answersRepository.getById(id);
    if (!answer) throw ApiError.notFound("Answer not found");
    answersRepository.softDelete(id, new Date().toISOString());
  }

  private checkRelations(questionId: number, userId: number): void {
    if (!questionsRepository.getById(questionId)) {
      throw ApiError.badRequest("Invalid request body", [
        { field: "questionId", message: "Question does not exist" },
      ]);
    }
    if (!usersRepository.getById(userId)) {
      throw ApiError.badRequest("Invalid request body", [
        { field: "userId", message: "User does not exist" },
      ]);
    }
  }
}

export const answersService = new AnswersService();
