import type { ListResponse } from "../models/common.model.js";
import type {
  CreatePollRequestDto,
  PatchPollRequestDto,
  PollResponseDto,
  UpdatePollRequestDto,
} from "../dtos/polls.dto.js";
import { toPollResponseDto } from "../dtos/polls.dto.js";
import { ApiError } from "../errors/ApiError.js";
import { pollsRepository } from "../repositories/polls.repository.js";
import { questionsRepository } from "../repositories/questions.repository.js";
import { compareValues, paginate, parseListQuery } from "../utils/listQuery.js";

export class PollsService {
  getList(query: Record<string, unknown>): ListResponse<PollResponseDto> {
    const listQuery = parseListQuery(query);
    const visibility = typeof query.visibility === "string" ? query.visibility : undefined;
    let items = pollsRepository.getAll(listQuery.includeDeleted);

    if (visibility) items = items.filter((poll) => poll.visibility === visibility);
    if (listQuery.search) {
      const search = listQuery.search.toLowerCase();
      items = items.filter(
        (poll) =>
          poll.title.toLowerCase().includes(search) || poll.author.toLowerCase().includes(search),
      );
    }

    const allowedSort = new Set(["id", "title", "author", "endDate", "visibility", "createdAt"]);
    if (listQuery.sortBy && allowedSort.has(listQuery.sortBy)) {
      items = [...items].sort((a, b) =>
        compareValues(
          String(a[listQuery.sortBy as keyof typeof a]),
          String(b[listQuery.sortBy as keyof typeof b]),
          listQuery.sortDir,
        ),
      );
    }

    const total = items.length;
    const pageItems = paginate(items, listQuery.page, listQuery.pageSize).map(toPollResponseDto);
    return { items: pageItems, total, page: listQuery.page, pageSize: listQuery.pageSize };
  }

  getById(id: number): PollResponseDto {
    const poll = pollsRepository.getById(id);
    if (!poll) throw ApiError.notFound("Poll not found");
    return toPollResponseDto(poll);
  }

  create(dto: CreatePollRequestDto): PollResponseDto {
    const exists = pollsRepository.findByTitleAndAuthor(dto.title, dto.author, true);
    if (exists && exists.deletedAt === null)
      throw ApiError.conflict("Poll with this title and author already exists");

    const now = new Date().toISOString();
    const poll = pollsRepository.create({
      ...dto,
      description: dto.description ?? "",
      createdAt: now,
      updatedAt: now,
      deletedAt: null,
    });
    return toPollResponseDto(poll);
  }

  update(id: number, dto: UpdatePollRequestDto): PollResponseDto {
    const current = pollsRepository.getById(id);
    if (!current) throw ApiError.notFound("Poll not found");

    const duplicate = pollsRepository.findByTitleAndAuthor(dto.title, dto.author);
    if (duplicate && duplicate.id !== id)
      throw ApiError.conflict("Poll with this title and author already exists");

    const updated = pollsRepository.replace(id, {
      ...dto,
      updatedAt: new Date().toISOString(),
      deletedAt: null,
    });
    if (!updated) throw ApiError.notFound("Poll not found");
    return toPollResponseDto(updated);
  }

  patch(id: number, dto: PatchPollRequestDto): PollResponseDto {
    const current = pollsRepository.getById(id);
    if (!current) throw ApiError.notFound("Poll not found");

    const nextTitle = dto.title ?? current.title;
    const nextAuthor = dto.author ?? current.author;
    const duplicate = pollsRepository.findByTitleAndAuthor(nextTitle, nextAuthor);
    if (duplicate && duplicate.id !== id)
      throw ApiError.conflict("Poll with this title and author already exists");

    const updated = pollsRepository.patch(id, { ...dto, updatedAt: new Date().toISOString() });
    if (!updated) throw ApiError.notFound("Poll not found");
    return toPollResponseDto(updated);
  }

  delete(id: number): void {
    const poll = pollsRepository.getById(id);
    if (!poll) throw ApiError.notFound("Poll not found");

    const relatedQuestions = questionsRepository.getByPollId(id);
    if (relatedQuestions.length > 0) {
      throw ApiError.conflict(
        "Poll cannot be deleted because poll has questions. Delete related questions first",
      );
    }

    pollsRepository.softDelete(id, new Date().toISOString());
  }
}

export const pollsService = new PollsService();
