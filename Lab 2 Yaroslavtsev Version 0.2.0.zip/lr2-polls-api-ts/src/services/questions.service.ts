import type { ListResponse } from "../models/common.model.js";
import type {
  CreateQuestionRequestDto,
  PatchQuestionRequestDto,
  QuestionResponseDto,
  UpdateQuestionRequestDto,
} from "../dtos/questions.dto.js";
import { toQuestionResponseDto } from "../dtos/questions.dto.js";
import { ApiError } from "../errors/ApiError.js";
import { answersRepository } from "../repositories/answers.repository.js";
import { pollsRepository } from "../repositories/polls.repository.js";
import { questionsRepository } from "../repositories/questions.repository.js";
import { compareValues, paginate, parseListQuery } from "../utils/listQuery.js";

export class QuestionsService {
  getList(query: Record<string, unknown>): ListResponse<QuestionResponseDto> {
    const listQuery = parseListQuery(query);
    const pollId = typeof query.pollId === "string" ? Number(query.pollId) : undefined;
    const type = typeof query.type === "string" ? query.type : undefined;
    let items = questionsRepository.getAll(listQuery.includeDeleted);

    if (pollId && Number.isInteger(pollId))
      items = items.filter((question) => question.pollId === pollId);
    if (type) items = items.filter((question) => question.type === type);
    if (listQuery.search) {
      const search = listQuery.search.toLowerCase();
      items = items.filter((question) => question.text.toLowerCase().includes(search));
    }

    const allowedSort = new Set(["id", "pollId", "order", "text", "type", "createdAt"]);
    if (listQuery.sortBy && allowedSort.has(listQuery.sortBy)) {
      items = [...items].sort((a, b) =>
        compareValues(
          String(a[listQuery.sortBy as keyof typeof a]),
          String(b[listQuery.sortBy as keyof typeof b]),
          listQuery.sortDir,
        ),
      );
    }

    const total = items.length;
    const pageItems = paginate(items, listQuery.page, listQuery.pageSize).map(
      toQuestionResponseDto,
    );
    return { items: pageItems, total, page: listQuery.page, pageSize: listQuery.pageSize };
  }

  getById(id: number): QuestionResponseDto {
    const question = questionsRepository.getById(id);
    if (!question) throw ApiError.notFound("Question not found");
    return toQuestionResponseDto(question);
  }

  create(dto: CreateQuestionRequestDto): QuestionResponseDto {
    const poll = pollsRepository.getById(dto.pollId);
    if (!poll)
      throw ApiError.badRequest("Invalid request body", [
        { field: "pollId", message: "Poll does not exist" },
      ]);

    const now = new Date().toISOString();
    const question = questionsRepository.create({
      ...dto,
      createdAt: now,
      updatedAt: now,
      deletedAt: null,
    });
    return toQuestionResponseDto(question);
  }

  update(id: number, dto: UpdateQuestionRequestDto): QuestionResponseDto {
    const current = questionsRepository.getById(id);
    if (!current) throw ApiError.notFound("Question not found");
    const poll = pollsRepository.getById(dto.pollId);
    if (!poll)
      throw ApiError.badRequest("Invalid request body", [
        { field: "pollId", message: "Poll does not exist" },
      ]);

    const updated = questionsRepository.replace(id, {
      ...dto,
      updatedAt: new Date().toISOString(),
      deletedAt: null,
    });
    if (!updated) throw ApiError.notFound("Question not found");
    return toQuestionResponseDto(updated);
  }

  patch(id: number, dto: PatchQuestionRequestDto): QuestionResponseDto {
    const current = questionsRepository.getById(id);
    if (!current) throw ApiError.notFound("Question not found");
    if (dto.pollId !== undefined && !pollsRepository.getById(dto.pollId)) {
      throw ApiError.badRequest("Invalid request body", [
        { field: "pollId", message: "Poll does not exist" },
      ]);
    }

    const updated = questionsRepository.patch(id, { ...dto, updatedAt: new Date().toISOString() });
    if (!updated) throw ApiError.notFound("Question not found");
    return toQuestionResponseDto(updated);
  }

  delete(id: number): void {
    const question = questionsRepository.getById(id);
    if (!question) throw ApiError.notFound("Question not found");

    const relatedAnswers = answersRepository.getByQuestionId(id);
    if (relatedAnswers.length > 0) {
      throw ApiError.conflict(
        "Question cannot be deleted because question has answers. Delete related answers first",
      );
    }

    questionsRepository.softDelete(id, new Date().toISOString());
  }
}

export const questionsService = new QuestionsService();
