import type { ListResponse } from "../models/common.model.js";
import type {
  CreateUserRequestDto,
  PatchUserRequestDto,
  UpdateUserRequestDto,
  UserResponseDto,
} from "../dtos/users.dto.js";
import { toUserResponseDto } from "../dtos/users.dto.js";
import { ApiError } from "../errors/ApiError.js";
import { usersRepository } from "../repositories/users.repository.js";
import { compareValues, paginate, parseListQuery } from "../utils/listQuery.js";

export class UsersService {
  getList(query: Record<string, unknown>): ListResponse<UserResponseDto> {
    const listQuery = parseListQuery(query);
    const role = typeof query.role === "string" ? query.role : undefined;
    let items = usersRepository.getAll(listQuery.includeDeleted);

    if (role) items = items.filter((user) => user.role === role);
    if (listQuery.search) {
      const search = listQuery.search.toLowerCase();
      items = items.filter(
        (user) =>
          user.name.toLowerCase().includes(search) || user.email.toLowerCase().includes(search),
      );
    }

    const allowedSort = new Set(["id", "name", "email", "role", "createdAt"]);
    if (listQuery.sortBy && allowedSort.has(listQuery.sortBy)) {
      items = [...items].sort((a, b) =>
        compareValues(
          String(a[listQuery.sortBy as keyof typeof a]),
          String(b[listQuery.sortBy as keyof typeof b]),
          listQuery.sortDir,
        ),
      );
    }

    const total = items.length;
    const pageItems = paginate(items, listQuery.page, listQuery.pageSize).map(toUserResponseDto);
    return { items: pageItems, total, page: listQuery.page, pageSize: listQuery.pageSize };
  }

  getById(id: number): UserResponseDto {
    const user = usersRepository.getById(id);
    if (!user) throw ApiError.notFound("User not found");
    return toUserResponseDto(user);
  }

  create(dto: CreateUserRequestDto): UserResponseDto {
    const exists = usersRepository.findByEmail(dto.email, true);
    if (exists && exists.deletedAt === null)
      throw ApiError.conflict("User with this email already exists");

    const now = new Date().toISOString();
    const user = usersRepository.create({
      ...dto,
      email: dto.email.toLowerCase(),
      createdAt: now,
      updatedAt: now,
      deletedAt: null,
    });
    return toUserResponseDto(user);
  }

  update(id: number, dto: UpdateUserRequestDto): UserResponseDto {
    const current = usersRepository.getById(id);
    if (!current) throw ApiError.notFound("User not found");

    const sameEmail = usersRepository.findByEmail(dto.email);
    if (sameEmail && sameEmail.id !== id)
      throw ApiError.conflict("User with this email already exists");

    const now = new Date().toISOString();
    const updated = usersRepository.replace(id, {
      ...dto,
      email: dto.email.toLowerCase(),
      updatedAt: now,
      deletedAt: null,
    });
    if (!updated) throw ApiError.notFound("User not found");
    return toUserResponseDto(updated);
  }

  patch(id: number, dto: PatchUserRequestDto): UserResponseDto {
    const current = usersRepository.getById(id);
    if (!current) throw ApiError.notFound("User not found");

    if (dto.email) {
      const sameEmail = usersRepository.findByEmail(dto.email);
      if (sameEmail && sameEmail.id !== id)
        throw ApiError.conflict("User with this email already exists");
    }

    const patch: PatchUserRequestDto & { updatedAt: string } = {
      ...dto,
      updatedAt: new Date().toISOString(),
    };
    if (dto.email !== undefined) patch.email = dto.email.toLowerCase();
    const updated = usersRepository.patch(id, patch);
    if (!updated) throw ApiError.notFound("User not found");
    return toUserResponseDto(updated);
  }

  delete(id: number): void {
    const user = usersRepository.getById(id);
    if (!user) throw ApiError.notFound("User not found");
    usersRepository.softDelete(id, new Date().toISOString());
  }
}

export const usersService = new UsersService();
