import express from "express";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { answersRouter } from "./routes/answers.routes.js";
import { pollsRouter } from "./routes/polls.routes.js";
import { questionsRouter } from "./routes/questions.routes.js";
import { usersRouter } from "./routes/users.routes.js";
import { errorHandler } from "./middleware/errorHandler.js";
import { notFoundHandler } from "./middleware/notFoundHandler.js";
import { requestLogger } from "./middleware/requestLogger.js";
import { openApiSpec } from "./openapi.js";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

export const app = express();

app.use(express.json());
app.use(requestLogger);

app.get("/health", (_req, res) => {
  res.status(200).json({ ok: true });
});

app.get("/openapi.json", (_req, res) => {
  res.status(200).json(openApiSpec);
});

app.get("/api-docs", (_req, res) => {
  res.status(200).send(`<!doctype html>
<html lang="uk">
<head>
  <meta charset="utf-8" />
  <title>Polls API Swagger UI</title>
  <link rel="stylesheet" href="https://unpkg.com/swagger-ui-dist@5/swagger-ui.css" />
</head>
<body>
  <div id="swagger-ui"></div>
  <script src="https://unpkg.com/swagger-ui-dist@5/swagger-ui-bundle.js"></script>
  <script>window.onload = () => window.ui = SwaggerUIBundle({ url: '/openapi.json', dom_id: '#swagger-ui' });</script>
</body>
</html>`);
});

app.use("/api/users", usersRouter);
app.use("/api/polls", pollsRouter);
app.use("/api/questions", questionsRouter);
app.use("/api/answers", answersRouter);

const publicPath = path.resolve(__dirname, "../public");
app.use(express.static(publicPath));

app.use(notFoundHandler);
app.use(errorHandler);
