import { Router } from "express";
import {
  createPoll,
  deletePoll,
  getPollById,
  getPollList,
  patchPoll,
  updatePoll,
} from "../controllers/polls.controller.js";
import { asyncHandler } from "../utils/asyncHandler.js";
import { validationMiddleware } from "../validation/validation.types.js";
import {
  validateCreatePoll,
  validatePatchPoll,
  validateUpdatePoll,
} from "../validation/polls.validators.js";

export const pollsRouter = Router();

pollsRouter.get("/", asyncHandler(getPollList));
pollsRouter.get("/:id", asyncHandler(getPollById));
pollsRouter.post("/", validationMiddleware(validateCreatePoll), asyncHandler(createPoll));
pollsRouter.put("/:id", validationMiddleware(validateUpdatePoll), asyncHandler(updatePoll));
pollsRouter.patch("/:id", validationMiddleware(validatePatchPoll), asyncHandler(patchPoll));
pollsRouter.delete("/:id", asyncHandler(deletePoll));
