import type { Request, Response } from "express";
import { answersService } from "../services/answers.service.js";
import { parseId } from "../utils/parseId.js";
import type {
  CreateAnswerRequestDto,
  UpdateAnswerRequestDto,
  PatchAnswerRequestDto,
} from "../dtos/answers.dto.js";

function queryToRecord(query: Request["query"]): Record<string, unknown> {
  return query as Record<string, unknown>;
}

export async function getAnswerList(req: Request, res: Response): Promise<void> {
  const result = answersService.getList(queryToRecord(req.query));
  res.status(200).json(result);
}

export async function getAnswerById(req: Request, res: Response): Promise<void> {
  const id = parseId(req.params.id);
  const result = answersService.getById(id);
  res.status(200).json(result);
}

export async function createAnswer(req: Request, res: Response): Promise<void> {
  const dto = req.body as CreateAnswerRequestDto;
  const result = answersService.create(dto);
  res.status(201).json(result);
}

export async function updateAnswer(req: Request, res: Response): Promise<void> {
  const id = parseId(req.params.id);
  const dto = req.body as UpdateAnswerRequestDto;
  const result = answersService.update(id, dto);
  res.status(200).json(result);
}

export async function patchAnswer(req: Request, res: Response): Promise<void> {
  const id = parseId(req.params.id);
  const dto = req.body as PatchAnswerRequestDto;
  const result = answersService.patch(id, dto);
  res.status(200).json(result);
}

export async function deleteAnswer(req: Request, res: Response): Promise<void> {
  const id = parseId(req.params.id);
  answersService.delete(id);
  res.status(204).send();
}
