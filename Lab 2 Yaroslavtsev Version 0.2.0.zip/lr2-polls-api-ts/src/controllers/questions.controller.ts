import type { Request, Response } from "express";
import { questionsService } from "../services/questions.service.js";
import { parseId } from "../utils/parseId.js";
import type {
  CreateQuestionRequestDto,
  UpdateQuestionRequestDto,
  PatchQuestionRequestDto,
} from "../dtos/questions.dto.js";

function queryToRecord(query: Request["query"]): Record<string, unknown> {
  return query as Record<string, unknown>;
}

export async function getQuestionList(req: Request, res: Response): Promise<void> {
  const result = questionsService.getList(queryToRecord(req.query));
  res.status(200).json(result);
}

export async function getQuestionById(req: Request, res: Response): Promise<void> {
  const id = parseId(req.params.id);
  const result = questionsService.getById(id);
  res.status(200).json(result);
}

export async function createQuestion(req: Request, res: Response): Promise<void> {
  const dto = req.body as CreateQuestionRequestDto;
  const result = questionsService.create(dto);
  res.status(201).json(result);
}

export async function updateQuestion(req: Request, res: Response): Promise<void> {
  const id = parseId(req.params.id);
  const dto = req.body as UpdateQuestionRequestDto;
  const result = questionsService.update(id, dto);
  res.status(200).json(result);
}

export async function patchQuestion(req: Request, res: Response): Promise<void> {
  const id = parseId(req.params.id);
  const dto = req.body as PatchQuestionRequestDto;
  const result = questionsService.patch(id, dto);
  res.status(200).json(result);
}

export async function deleteQuestion(req: Request, res: Response): Promise<void> {
  const id = parseId(req.params.id);
  questionsService.delete(id);
  res.status(204).send();
}
