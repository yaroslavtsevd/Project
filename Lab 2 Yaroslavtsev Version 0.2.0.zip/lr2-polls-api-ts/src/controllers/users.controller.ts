import type { Request, Response } from "express";
import { usersService } from "../services/users.service.js";
import { parseId } from "../utils/parseId.js";
import type {
  CreateUserRequestDto,
  UpdateUserRequestDto,
  PatchUserRequestDto,
} from "../dtos/users.dto.js";

function queryToRecord(query: Request["query"]): Record<string, unknown> {
  return query as Record<string, unknown>;
}

export async function getUserList(req: Request, res: Response): Promise<void> {
  const result = usersService.getList(queryToRecord(req.query));
  res.status(200).json(result);
}

export async function getUserById(req: Request, res: Response): Promise<void> {
  const id = parseId(req.params.id);
  const result = usersService.getById(id);
  res.status(200).json(result);
}

export async function createUser(req: Request, res: Response): Promise<void> {
  const dto = req.body as CreateUserRequestDto;
  const result = usersService.create(dto);
  res.status(201).json(result);
}

export async function updateUser(req: Request, res: Response): Promise<void> {
  const id = parseId(req.params.id);
  const dto = req.body as UpdateUserRequestDto;
  const result = usersService.update(id, dto);
  res.status(200).json(result);
}

export async function patchUser(req: Request, res: Response): Promise<void> {
  const id = parseId(req.params.id);
  const dto = req.body as PatchUserRequestDto;
  const result = usersService.patch(id, dto);
  res.status(200).json(result);
}

export async function deleteUser(req: Request, res: Response): Promise<void> {
  const id = parseId(req.params.id);
  usersService.delete(id);
  res.status(204).send();
}
