import type { Request, Response } from "express";
import { pollsService } from "../services/polls.service.js";
import { parseId } from "../utils/parseId.js";
import type {
  CreatePollRequestDto,
  UpdatePollRequestDto,
  PatchPollRequestDto,
} from "../dtos/polls.dto.js";

function queryToRecord(query: Request["query"]): Record<string, unknown> {
  return query as Record<string, unknown>;
}

export async function getPollList(req: Request, res: Response): Promise<void> {
  const result = pollsService.getList(queryToRecord(req.query));
  res.status(200).json(result);
}

export async function getPollById(req: Request, res: Response): Promise<void> {
  const id = parseId(req.params.id);
  const result = pollsService.getById(id);
  res.status(200).json(result);
}

export async function createPoll(req: Request, res: Response): Promise<void> {
  const dto = req.body as CreatePollRequestDto;
  const result = pollsService.create(dto);
  res.status(201).json(result);
}

export async function updatePoll(req: Request, res: Response): Promise<void> {
  const id = parseId(req.params.id);
  const dto = req.body as UpdatePollRequestDto;
  const result = pollsService.update(id, dto);
  res.status(200).json(result);
}

export async function patchPoll(req: Request, res: Response): Promise<void> {
  const id = parseId(req.params.id);
  const dto = req.body as PatchPollRequestDto;
  const result = pollsService.patch(id, dto);
  res.status(200).json(result);
}

export async function deletePoll(req: Request, res: Response): Promise<void> {
  const id = parseId(req.params.id);
  pollsService.delete(id);
  res.status(204).send();
}
