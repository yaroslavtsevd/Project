import type { BaseEntity } from "../models/common.model.js";

export class InMemoryRepository<T extends BaseEntity> {
  protected items: T[];
  private nextId: number;

  constructor(seed: T[] = []) {
    this.items = seed;
    this.nextId = seed.reduce((max, item) => Math.max(max, item.id), 0) + 1;
  }

  getAll(includeDeleted = false): T[] {
    return this.items.filter((item) => includeDeleted || item.deletedAt === null);
  }

  getById(id: number, includeDeleted = false): T | null {
    return (
      this.items.find((item) => item.id === id && (includeDeleted || item.deletedAt === null)) ??
      null
    );
  }

  create(data: Omit<T, "id">): T {
    const entity = { ...data, id: this.nextId } as T;
    this.nextId += 1;
    this.items.push(entity);
    return entity;
  }

  replace(id: number, data: Omit<T, "id" | "createdAt">): T | null {
    const index = this.items.findIndex((item) => item.id === id && item.deletedAt === null);
    if (index === -1) return null;

    const current = this.items[index];
    if (!current) return null;

    const next = { ...data, id, createdAt: current.createdAt } as T;
    this.items[index] = next;
    return next;
  }

  patch(id: number, patch: Partial<Omit<T, "id" | "createdAt">>): T | null {
    const index = this.items.findIndex((item) => item.id === id && item.deletedAt === null);
    if (index === -1) return null;

    const current = this.items[index];
    if (!current) return null;

    const next = { ...current, ...patch } as T;
    this.items[index] = next;
    return next;
  }

  softDelete(id: number, deletedAt: string): T | null {
    return this.patch(id, { deletedAt, updatedAt: deletedAt } as Partial<
      Omit<T, "id" | "createdAt">
    >);
  }

  hardDelete(id: number): boolean {
    const lengthBefore = this.items.length;
    this.items = this.items.filter((item) => item.id !== id);
    return this.items.length !== lengthBefore;
  }

  reset(seed: T[] = []): void {
    this.items = seed;
    this.nextId = seed.reduce((max, item) => Math.max(max, item.id), 0) + 1;
  }
}
