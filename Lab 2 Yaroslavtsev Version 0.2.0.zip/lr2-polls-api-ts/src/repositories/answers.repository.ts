import type { AnswerEntity } from "../models/answer.model.js";
import { InMemoryRepository } from "./base.repository.js";

const now = "2026-05-07T10:00:00.000Z";

const seedAnswers: AnswerEntity[] = [
  {
    id: 1,
    questionId: 1,
    userId: 1,
    value: "Web API",
    createdAt: now,
    updatedAt: now,
    deletedAt: null,
  },
  {
    id: 2,
    questionId: 2,
    userId: 2,
    value: "Середа",
    createdAt: now,
    updatedAt: now,
    deletedAt: null,
  },
];

class AnswersRepository extends InMemoryRepository<AnswerEntity> {
  findByQuestionAndUser(
    questionId: number,
    userId: number,
    includeDeleted = false,
  ): AnswerEntity | null {
    return (
      this.getAll(includeDeleted).find(
        (answer) => answer.questionId === questionId && answer.userId === userId,
      ) ?? null
    );
  }

  getByQuestionId(questionId: number, includeDeleted = false): AnswerEntity[] {
    return this.getAll(includeDeleted).filter((answer) => answer.questionId === questionId);
  }
}

export const answersRepository = new AnswersRepository(seedAnswers);
export { seedAnswers };
