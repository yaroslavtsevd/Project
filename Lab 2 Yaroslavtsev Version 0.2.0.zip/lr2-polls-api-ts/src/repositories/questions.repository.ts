import type { QuestionEntity } from "../models/question.model.js";
import { InMemoryRepository } from "./base.repository.js";

const now = "2026-05-07T10:00:00.000Z";

const seedQuestions: QuestionEntity[] = [
  {
    id: 1,
    pollId: 1,
    text: "Яку тему обираємо?",
    type: "single",
    options: ["Web API", "Frontend", "Кібербезпека"],
    order: 1,
    createdAt: now,
    updatedAt: now,
    deletedAt: null,
  },
  {
    id: 2,
    pollId: 2,
    text: "Коли зручно прийти на консультацію?",
    type: "single",
    options: ["Понеділок", "Середа", "Пʼятниця"],
    order: 1,
    createdAt: now,
    updatedAt: now,
    deletedAt: null,
  },
];

class QuestionsRepository extends InMemoryRepository<QuestionEntity> {
  getByPollId(pollId: number, includeDeleted = false): QuestionEntity[] {
    return this.getAll(includeDeleted).filter((question) => question.pollId === pollId);
  }
}

export const questionsRepository = new QuestionsRepository(seedQuestions);
export { seedQuestions };
