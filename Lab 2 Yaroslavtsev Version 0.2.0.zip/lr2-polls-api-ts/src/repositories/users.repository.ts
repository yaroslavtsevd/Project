import type { UserEntity } from "../models/user.model.js";
import { InMemoryRepository } from "./base.repository.js";

const now = "2026-05-07T10:00:00.000Z";

const seedUsers: UserEntity[] = [
  {
    id: 1,
    name: "Оксана Дудар",
    email: "oksana@example.com",
    role: "Student",
    createdAt: now,
    updatedAt: now,
    deletedAt: null,
  },
  {
    id: 2,
    name: "Марія Іваненко",
    email: "maria@example.com",
    role: "Student",
    createdAt: now,
    updatedAt: now,
    deletedAt: null,
  },
  {
    id: 3,
    name: "Викладач",
    email: "teacher@example.com",
    role: "Teacher",
    createdAt: now,
    updatedAt: now,
    deletedAt: null,
  },
];

class UsersRepository extends InMemoryRepository<UserEntity> {
  findByEmail(email: string, includeDeleted = false): UserEntity | null {
    const normalized = email.trim().toLowerCase();
    return (
      this.getAll(includeDeleted).find((user) => user.email.toLowerCase() === normalized) ?? null
    );
  }
}

export const usersRepository = new UsersRepository(seedUsers);
export { seedUsers };
