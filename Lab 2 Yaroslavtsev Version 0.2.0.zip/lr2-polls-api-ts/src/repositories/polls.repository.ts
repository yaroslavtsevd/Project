import type { PollEntity } from "../models/poll.model.js";
import { InMemoryRepository } from "./base.repository.js";

const now = "2026-05-07T10:00:00.000Z";

const seedPolls: PollEntity[] = [
  {
    id: 1,
    title: "Вибір теми проєкту",
    author: "Oleg",
    endDate: "2026-06-01",
    visibility: "Public",
    description: "Опитування для вибору теми командного проєкту.",
    createdAt: now,
    updatedAt: now,
    deletedAt: null,
  },
  {
    id: 2,
    title: "Розклад консультацій",
    author: "Anatoliy",
    endDate: "2026-06-10",
    visibility: "Private",
    description: "Вибір зручного часу для консультації групи.",
    createdAt: now,
    updatedAt: now,
    deletedAt: null,
  },
];

class PollsRepository extends InMemoryRepository<PollEntity> {
  findByTitleAndAuthor(title: string, author: string, includeDeleted = false): PollEntity | null {
    const normalizedTitle = title.trim().toLowerCase();
    const normalizedAuthor = author.trim().toLowerCase();
    return (
      this.getAll(includeDeleted).find(
        (poll) =>
          poll.title.toLowerCase() === normalizedTitle &&
          poll.author.toLowerCase() === normalizedAuthor,
      ) ?? null
    );
  }
}

export const pollsRepository = new PollsRepository(seedPolls);
export { seedPolls };
