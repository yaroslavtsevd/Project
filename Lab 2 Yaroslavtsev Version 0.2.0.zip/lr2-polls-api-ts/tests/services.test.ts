import assert from "node:assert/strict";
import test from "node:test";
import { answersService } from "../src/services/answers.service.js";
import { pollsService } from "../src/services/polls.service.js";
import { questionsService } from "../src/services/questions.service.js";
import { usersService } from "../src/services/users.service.js";
import { answersRepository, seedAnswers } from "../src/repositories/answers.repository.js";
import { pollsRepository, seedPolls } from "../src/repositories/polls.repository.js";
import { questionsRepository, seedQuestions } from "../src/repositories/questions.repository.js";
import { seedUsers, usersRepository } from "../src/repositories/users.repository.js";
import { ApiError } from "../src/errors/ApiError.js";

function resetData(): void {
  usersRepository.reset(seedUsers.map((item) => ({ ...item })));
  pollsRepository.reset(seedPolls.map((item) => ({ ...item })));
  questionsRepository.reset(seedQuestions.map((item) => ({ ...item, options: [...item.options] })));
  answersRepository.reset(
    seedAnswers.map((item) => ({
      ...item,
      value: Array.isArray(item.value) ? [...item.value] : item.value,
    })),
  );
}

test("UsersService creates a user and returns response DTO with id", () => {
  resetData();
  const user = usersService.create({
    name: "Новий Студент",
    email: "new@example.com",
    role: "Student",
  });
  assert.equal(user.id, 4);
  assert.equal(user.email, "new@example.com");
});

test("UsersService returns 409 for duplicate email", () => {
  resetData();
  assert.throws(
    () => usersService.create({ name: "Дубль", email: "oksana@example.com", role: "Student" }),
    (error: unknown) => error instanceof ApiError && error.status === 409,
  );
});

test("PollsService supports filtering and pagination", () => {
  resetData();
  const result = pollsService.getList({ visibility: "Public", page: "1", pageSize: "1" });
  assert.equal(result.items.length, 1);
  assert.equal(result.total, 1);
  assert.equal(result.items[0]?.visibility, "Public");
});

test("PollsService blocks deleting poll that has questions", () => {
  resetData();
  assert.throws(
    () => pollsService.delete(1),
    (error: unknown) => error instanceof ApiError && error.status === 409,
  );
});

test("AnswersService blocks duplicate answer for same user and question", () => {
  resetData();
  assert.throws(
    () => answersService.create({ questionId: 1, userId: 1, value: "Frontend" }),
    (error: unknown) => error instanceof ApiError && error.status === 409,
  );
});

test("QuestionsService creates question for existing poll", () => {
  resetData();
  const question = questionsService.create({
    pollId: 1,
    text: "Додаткове питання?",
    type: "text",
    options: [],
    order: 2,
  });
  assert.equal(question.pollId, 1);
  assert.equal(question.type, "text");
});
