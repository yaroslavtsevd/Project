# Лабораторна робота №2 — TypeScript REST API для системи опитування групи

Cутності:

- `Users`
- `Polls`
- `Questions`
- `Answers`

## 1. Запуск

```bash
cd Backe
npm install
npm run dev
```

Сервер запускається на:

```text
http://localhost:3000
```

Frontend відкривається тут:

```text
http://localhost:3000
```

Swagger UI:

```text
http://localhost:3000/api-docs
```

OpenAPI JSON:

```text
http://localhost:3000/openapi.json
```

## 2. Збірка

```bash
npm run build
npm start
```

## 3. Перевірка якості

```bash
npm run lint
npm run format
npm test
```


## 4. Архітектура

```text
src/
  app.ts
  index.ts
  openapi.ts
  routes/          
  controllers/     
  services/        
  repositories/    
  dtos/            
  models/          
  validation/      
  middleware/      
  errors/          
  utils/           
```

## 5. Єдиний формат списків

Усі `GET list` повертають однакову структуру:

```json
{
  "items": [],
  "total": 0,
  "page": 1,
  "pageSize": 10
}
```

## 6. Єдиний формат помилок

Усі помилки повертаються однаково:

```json
{
  "error": {
    "code": "VALIDATION_ERROR",
    "message": "Invalid request body",
    "details": [
      {
        "field": "title",
        "message": "title length must be between 3 and 80"
      }
    ]
  }
}
```

Приклади HTTP-кодів:

- `400 VALIDATION_ERROR` — невалідний body або route param.
- `404 NOT_FOUND` — ресурс не знайдено.
- `409 CONFLICT` — конфлікт стану, наприклад дубль email або спроба видалити Poll, який має Questions.
- `500 INTERNAL_SERVER_ERROR` — неочікувана помилка.

## 7. Додаткові REST-можливості

1. Фільтрація через query params.
2. Пагінація через `page` і `pageSize`.
3. Сортування через `sortBy` і `sortDir`.
4. Часткове оновлення через `PATCH`.
5. Soft delete: `DELETE` ставить `deletedAt`, а не видаляє запис фізично.

Приклад:

```bash
curl -i "http://localhost:3000/api/polls?visibility=Public&page=1&pageSize=5&sortBy=endDate&sortDir=desc"
```

## 8. CRUD-маршрути

### Users

```text
GET    /api/users
GET    /api/users/:id
POST   /api/users
PUT    /api/users/:id
PATCH  /api/users/:id
DELETE /api/users/:id
```

### Polls

```text
GET    /api/polls
GET    /api/polls/:id
POST   /api/polls
PUT    /api/polls/:id
PATCH  /api/polls/:id
DELETE /api/polls/:id
```

### Questions

```text
GET    /api/questions
GET    /api/questions/:id
POST   /api/questions
PUT    /api/questions/:id
PATCH  /api/questions/:id
DELETE /api/questions/:id
```

### Answers

```text
GET    /api/answers
GET    /api/answers/:id
POST   /api/answers
PUT    /api/answers/:id
PATCH  /api/answers/:id
DELETE /api/answers/:id
```

## 9. Curl-сценарії для захисту

### Health check

```bash
curl -i http://localhost:3000/health
```

Очікується: `200 OK`.

### GET list з пагінацією, фільтрацією і сортуванням

```bash
curl -i "http://localhost:3000/api/polls?visibility=Public&page=1&pageSize=10&sortBy=endDate&sortDir=desc"
```

Очікується: `200 OK`, JSON з `items`, `total`, `page`, `pageSize`.

### POST Poll — успішне створення

PowerShell:

```powershell
curl.exe -i -X POST http://localhost:3000/api/polls `
  -H "Content-Type: application/json" `
  -d "{\"title\":\"Нове опитування\",\"author\":\"Oleg\",\"endDate\":\"2026-06-20\",\"visibility\":\"Public\",\"description\":\"Короткий опис\"}"
```

Очікувано: `201 Created`.

### PATCH Poll — часткове оновлення

```powershell
curl.exe -i -X PATCH http://localhost:3000/api/polls/1 `
  -H "Content-Type: application/json" `
  -d "{\"description\":\"Оновлений опис через PATCH\"}"
```

Очікувано: `200 OK`.

### 400 — помилка валідації

```powershell
curl.exe -i -X POST http://localhost:3000/api/polls `
  -H "Content-Type: application/json" `
  -d "{\"title\":\"No\",\"author\":\"A\",\"endDate\":\"bad-date\",\"visibility\":\"Hidden\"}"
```

Очікувано: `400 Bad Request` і стабільний формат помилки.

### 404 — неіснуючий ID

```bash
curl -i http://localhost:3000/api/polls/999
```

Очікувано: `404 Not Found`.


### 409 — конфлікт видалення Poll, який має Questions

```bash
curl -i -X DELETE http://localhost:3000/api/polls/1
```

Очікувано: `409 Conflict`, бо до Poll привʼязані Questions.

### Soft delete

```powershell
curl.exe -i -X POST http://localhost:3000/api/polls `
  -H "Content-Type: application/json" `
  -d "{\"title\":\"Тимчасове опитування\",\"author\":\"Oleg\",\"endDate\":\"2026-07-01\",\"visibility\":\"Public\",\"description\":\"Для перевірки soft delete\"}"
```

```bash
curl -i -X DELETE http://localhost:3000/api/polls/3
```

Очікувано: `204 No Content`.

Щоб побачити soft-deleted записи:

```bash
curl -i "http://localhost:3000/api/polls?includeDeleted=true"
```

## 10. Unit-тести сервісів

Реалізовано мінімум 5 unit-тестів:

1. створення користувача;
2. фільтрація і пагінація Polls;
3. блокування видалення Poll, який має Questions;
4. блокування дублювання Answer;
5. створення Question для існуючого Poll.

Запуск:

```bash
npm test
```
